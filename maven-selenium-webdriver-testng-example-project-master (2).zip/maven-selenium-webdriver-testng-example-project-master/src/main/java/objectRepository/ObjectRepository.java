package objectRepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ObjectRepository {
	
	public WebDriver driver;
	
	@FindBy(xpath="//*[@title='Breaking News Alerts']")
	static
	WebElement bellicon;
	
	@FindBy(xpath="//*[@class='popover-content']//div")
	static
	WebElement subscribepopup;
	
	@FindBy(xpath="//*[@class='allow']")
	static
	WebElement allow;
	
	@FindBy(xpath="//*[@id=\"___ndtvspldiv\"]/span/div/div[2]/a")
	static
	WebElement ClickPopup;
	

	
	// constructor method
	public ObjectRepository(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	static public WebElement bellIconHome() {
		return bellicon;
	}
	
	static public WebElement Subscribe() {
		return subscribepopup;
	}
	
	static public WebElement AllowPopUp() {
		return allow;
	}
	
	static public WebElement  Popup() {
		return ClickPopup;
	}
	



}
