package variables;

public final class UrlVariables {
	public static final String BASE_URL = "https://ndtv.com";

}
