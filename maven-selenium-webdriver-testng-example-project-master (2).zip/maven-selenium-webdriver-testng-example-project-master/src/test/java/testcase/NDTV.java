package testcase;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import junit.framework.Assert;
import objectRepository.ObjectRepository;
import objectRepository.ObjectRepository.*;



public class NDTV {

	
	@Test
	public void Homepage() {

		BrowserSetting bs = new BrowserSetting();
		WebDriver driver = bs.BrowserSettings();

	    WebDriverWait wait = new WebDriverWait(driver,30);
		ObjectRepository home = new ObjectRepository(driver);
	  
	 try {
		 wait.until(ExpectedConditions.alertIsPresent()).accept();
		 System.out.println("In Try");
	     }
	 
	 catch(NoAlertPresentException e)
	  
	  {
		  home.AllowPopUp().click();
		  System.out.println("In catch");
		
	  }
	
	    home.bellIconHome().click();
	    
	    String abc=  home.Subscribe().getText();
	    String result="You have subscribed to our news updates. To unsubscribe, ";
	    
	    if(abc.equals(result)) {
	    	
	    System.out.println("Text Verified");
	    
	    }
	    
	    else
	    	
	    {
	    	 System.out.println("Text Verifiction failed");
	 	    
	    }	
	    
	    home.Popup().click();
	    
	
	    try {
	    wait.until(ExpectedConditions.alertIsPresent()).accept();
	    }
	    
	    catch(Exception e) {
	    home.AllowPopUp().click();
	
	    }
	
	
	}
	    
	    
		
		
	

}
